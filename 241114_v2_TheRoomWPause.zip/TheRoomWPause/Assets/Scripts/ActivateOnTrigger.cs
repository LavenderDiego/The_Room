using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ActivateOnTrigger : MonoBehaviour
{
    public SimpleFPS FPSController;  // Player controller
    public GameObject objectToActivate;
    public Rigidbody playerRigid;

    private bool isPlayerInTrigger = false;
    private bool isObjectActive = false;  // Track if object is active

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))  // Ensure it's the player entering the trigger
        {
            isPlayerInTrigger = true;
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            isPlayerInTrigger = false;
        }
    }

    private void Update()
    {
        if (isPlayerInTrigger && Input.GetKeyDown(KeyCode.F))
        {
            if (objectToActivate != null)
            {
                isObjectActive = !isObjectActive;  // Toggle active state

                objectToActivate.SetActive(isObjectActive);
                playerRigid.isKinematic = isObjectActive;
                FPSController.enabled = !isObjectActive;

                // Show or hide the mouse cursor
                Cursor.visible = isObjectActive;
                Cursor.lockState = isObjectActive ? CursorLockMode.None : CursorLockMode.Locked;
            }
        }
    }
}