﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OpenKeyPad : MonoBehaviour
{
    public GameObject keypadOB;
    //public GameObject keypadText;

   // public bool inReach;


    void Start()
    {
       // inReach = false;
    }

 



    void Update()
    {
        if(Input.GetButtonDown("F"))
        {
            keypadOB.SetActive(true);
        }
        

    }
}
