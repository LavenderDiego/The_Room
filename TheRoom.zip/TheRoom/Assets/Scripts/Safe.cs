using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Safe : MonoBehaviour
{
    public GameObject safecode, numtext, incorrecttext, correcttext;  // Unique UI elements for each safe
    public SimpleFPS FPSController;  // Player controller
    public Animator safeOpen;  // Animator for safe opening
    public Text numTex;  // Text field for displaying the code
    public string codeString = "";
    public string correctCode;  // Code input and correct code for the safe
    public int stringCharacters = 0;  // Count of characters entered
    public bool interactable = false, codeDone = false, safeactive = false;  // State variables
    public Button but1, but2, but3, but4, but5, but6, but7, but8, but9, but0;  // Buttons for number input
    private int token = 0;  // Used to prevent triggering open/close multiple times
    public Rigidbody playerRigid;  // Player Rigidbody to freeze movement

    // Detect player proximity to the safe
    void OnTriggerStay(Collider other)
    {
        if (other.CompareTag("MainCamera") && !codeDone)
        {
            interactable = true;
        }
    }

    // Detect when the player leaves the safe's area
    void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("MainCamera"))
        {
            interactable = false;
        }
    }

    void Update()
    {
        // Interact with the safe if player presses "F" and the safe is interactable
        if (interactable)
        {
            if (Input.GetKeyDown(KeyCode.F))
            {
                Debug.Log("Opening safecode UI for: " + gameObject.name);  // Track which safe is interacted with
                safecode.SetActive(true);  // Show the safe's UI
                playerRigid.constraints = RigidbodyConstraints.FreezeAll;  // Freeze player movement
                  // Disable FPS controller
                safeactive = true;
                FPSController.enabled = false;
                Cursor.visible = true;  // Show the mouse cursor
                Cursor.lockState = CursorLockMode.None;  // Unlock cursor
                interactable = false;  // Disable further interactions until UI is closed
            }
        }

        // Handle the safe's code input UI
        if (safeactive)
        {
            // Close the UI if "Escape" is pressed
            if (Input.GetKeyDown(KeyCode.Escape))
            {
                ResetSafeState();  // Reset safe state when UI is closed
            }

            // Display the current code string in the text field
            numTex.text = codeString;

            // Check if 4 characters have been entered and validate the code
            if (stringCharacters == 4)
            {
                CheckCode();  // Check if the entered code is correct
            }
        }
    }

    // Check if the entered code is correct
    void CheckCode()
    {
        Debug.Log($"Checking code for {gameObject.name}. Entered: {codeString}, Correct: {correctCode}"); // Debugging statement
        if (codeString == correctCode)
        {
            numtext.SetActive(false);  // Hide the code input text
            correcttext.SetActive(true);  // Show the correct code message
            DisableButtons();  // Disable number input buttons
            codeDone = true;

            if (token == 0)  // Prevent multiple triggers
            {
                safeOpen.SetTrigger("open");  // Trigger the safe open animation
                StartCoroutine(EndSession());  // Start the session end coroutine
                token = 1;
            }
        }
        else
        {
            numtext.SetActive(false);
            incorrecttext.SetActive(true);  // Show the incorrect code message
            DisableButtons();
            if (token == 0)
            {
                StartCoroutine(EndSession());
                token = 1;
            }
        }
    }

    // Coroutine to reset the safe after a delay
    IEnumerator EndSession()
    {
        yield return new WaitForSeconds(2.5f);  // Wait 2.5 seconds before resetting
        ResetSafeState();
    }

    // Reset the safe's state after exiting the UI or after incorrect/correct entry
    public void ResetSafeState()
    {
        numtext.SetActive(true);  // Show the input field again
        correcttext.SetActive(false);  // Hide the correct message
        incorrecttext.SetActive(false);  // Hide the incorrect message
        stringCharacters = 0;  // Reset the character count
        codeString = "";  // Clear the code input string
        EnableButtons();  // Enable buttons for new input
        safeactive = false;  // Mark the safe as inactive
        token = 0;  // Reset token to allow future interaction
        safecode.SetActive(false);  // Hide the safe's UI
        
        playerRigid.constraints = RigidbodyConstraints.FreezePositionZ | RigidbodyConstraints.FreezePositionX |
                                  RigidbodyConstraints.FreezeRotationY | RigidbodyConstraints.FreezeRotationZ |
                                  RigidbodyConstraints.FreezeRotationX;  // Restore player movement constraints
        interactable = false;  // Make the safe non-interactable again
        FPSController.enabled = true;  // Enable FPS controller again
        Cursor.visible = false;  // Hide the cursor
        Cursor.lockState = CursorLockMode.Locked;  // Lock the cursor again
    }

    // Enable all buttons for input
    private void EnableButtons()
    {
        but1.interactable = true;
        but2.interactable = true;
        but3.interactable = true;
        but4.interactable = true;
        but5.interactable = true;
        but6.interactable = true;
        but7.interactable = true;
        but8.interactable = true;
        but9.interactable = true;
        but0.interactable = true;
    }

    // Disable all buttons after a code entry attempt
    private void DisableButtons()
    {
        but1.interactable = false;
        but2.interactable = false;
        but3.interactable = false;
        but4.interactable = false;
        but5.interactable = false;
        but6.interactable = false;
        but7.interactable = false;
        but8.interactable = false;
        but9.interactable = false;
        but0.interactable = false;
    }

    // Button press methods to add digits to the code string
    public void pressedOne()
    {
        codeString += "1";
        stringCharacters++;
    }
    public void pressedTwo()
    {
        codeString += "2";
        stringCharacters++;
    }
    public void pressedThree()
    {
        codeString += "3";
        stringCharacters++;
    }
    public void pressedFour()
    {
        codeString += "4";
        stringCharacters++;
    }
    public void pressedFive()
    {
        codeString += "5";
        stringCharacters++;
    }
    public void pressedSix()
    {
        codeString += "6";
        stringCharacters++;
    }
    public void pressedSeven()
    {
        codeString += "7";
        stringCharacters++;
    }
    public void pressedEight()
    {
        codeString += "8";
        stringCharacters++;
    }
    public void pressedNine()
    {
        codeString += "9";
        stringCharacters++;
    }
    public void pressedZero()
    {
        codeString += "0";
        stringCharacters++;
    }
}
