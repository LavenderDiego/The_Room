using UnityEngine;
using UnityEngine.UI;

public class SimpleSafe : MonoBehaviour
{
    public GameObject safecode;
    public Text numTex;
    public string correctCode = "1234";  // Set a simple correct code for testing
    private string codeString = "";
    private int stringCharacters = 0;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.F))
        {
            safecode.SetActive(true);
        }
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            safecode.SetActive(false);
        }

        numTex.text = codeString;

        if (stringCharacters == 4)
        {
            CheckCode();
        }
    }

    public void AddDigit(string digit)
    {
        if (stringCharacters < 4) // Prevent adding more than 4 digits
        {
            codeString += digit;
            stringCharacters++;
        }
    }

    void CheckCode()
    {
        if (codeString == correctCode)
        {
            Debug.Log("Correct Code!");
            // Perform actions for correct code
        }
        else
        {
            Debug.Log("Incorrect Code!");
            // Perform actions for incorrect code
        }
    }


    public void pressedOne()
    {
        codeString += "1";
        stringCharacters++;
    }
    public void pressedTwo()
    {
        codeString += "2";
        stringCharacters++;
    }
    public void pressedThree()
    {
        codeString += "3";
        stringCharacters++;
    }
    public void pressedFour()
    {
        codeString += "4";
        stringCharacters++;
    }
    public void pressedFive()
    {
        codeString += "5";
        stringCharacters++;
    }
    public void pressedSix()
    {
        codeString += "6";
        stringCharacters++;
    }
    public void pressedSeven()
    {
        codeString += "7";
        stringCharacters++;
    }
    public void pressedEight()
    {
        codeString += "8";
        stringCharacters++;
    }
    public void pressedNine()
    {
        codeString += "9";
        stringCharacters++;
    }
    public void pressedZero()
    {
        codeString += "0";
        stringCharacters++;
    }
}
