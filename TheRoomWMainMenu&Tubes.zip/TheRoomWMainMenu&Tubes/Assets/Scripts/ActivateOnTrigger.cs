using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ActivateOnTrigger : MonoBehaviour
{
    public SimpleFPS FPSController;  // Player controller
    public GameObject objectToActivate;
    public Rigidbody playerRigid;

    private bool isPlayerInTrigger = false;

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))  // Ensure it's the player entering the trigger
        {
            isPlayerInTrigger = true;
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            isPlayerInTrigger = false;
        }
    }

    private void Update()
    {
        if (isPlayerInTrigger && Input.GetKeyDown(KeyCode.F))
        {
            if (objectToActivate != null)
            {
                objectToActivate.SetActive(true);
                FPSController.enabled = false;
                Cursor.visible = true;  // Show the mouse cursor
                Cursor.lockState = CursorLockMode.None;  // Unlock cursor
                playerRigid.constraints = RigidbodyConstraints.FreezePositionZ | RigidbodyConstraints.FreezePositionX |
                                      RigidbodyConstraints.FreezeRotationY | RigidbodyConstraints.FreezeRotationZ |
                                      RigidbodyConstraints.FreezeRotationX;
            }
        }
        else if (Input.GetKeyDown(KeyCode.Escape))
        {
            objectToActivate.SetActive(false);
            FPSController.enabled = true;  // Enable FPS controller again
            Cursor.visible = false;  // Hide the cursor
            Cursor.lockState = CursorLockMode.Locked;  // Lock the cursor again
            Cursor.lockState = CursorLockMode.Locked;  // Lock the cursor again
            //playerRigid.constraints = RigidbodyConstraints.FreezePositionZ | RigidbodyConstraints.FreezePositionX |RigidbodyConstraints.FreezeRotationY | RigidbodyConstraints.FreezeRotationZ | RigidbodyConstraints.FreezeRotationX;
        }
    }
}
