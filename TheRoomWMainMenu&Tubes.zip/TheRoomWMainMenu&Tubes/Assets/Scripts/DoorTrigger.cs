using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DoorTrigger : MonoBehaviour
{

    [SerializeField]
    GameObject door;

    bool isOpened = false;
    void OnTriggerEnter(Collider col)
    {
        if (isOpened == false)
        {
            door.transform.position += new Vector3(0, 4, 0);
            isOpened = true;
        }

    }
    void OnTriggerExit(Collider col)
    {
        if (isOpened)
        {
            door.transform.position -= new Vector3(0, 4, 0); // Close the door
            isOpened = false;
        }
    }

    private void Update()
    {
        
    }
}