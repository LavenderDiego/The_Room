using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class KeypadV2 : MonoBehaviour
{
    public GameObject keypadUI; // Assign your keypad UI GameObject
    public Text codeDisplay; // Assign the Text UI element to display the entered code
    [SerializeField] string correctCode; // Set the correct code
    private string inputCode = ""; // Store the entered code
    [SerializeField] int maxCodeLength; // Maximum number of digits in the code
    public SimpleFPS FPSController;  // Player controller
    public Rigidbody playerRigid;  // Player Rigidbody to freeze movement
    public bool isActive = false;
    [SerializeField] GameObject door;
    [SerializeField] GameObject disable;


    void Start()
    {
        //ToggleKeypad(); 
    }

    void Update()
    {
       
    }

    // Method to toggle the keypad visibility
    private void ToggleKeypad()
    {
        isActive = true;
        playerRigid.constraints = RigidbodyConstraints.FreezeAll;  // Freeze player movement
        keypadUI.SetActive(true); // Toggle the keypad UI
        FPSController.enabled = false;
        Cursor.visible = true;  // Show the mouse cursor
        Cursor.lockState = CursorLockMode.None;  // Unlock cursor
    }

    // Method to add a digit to the code
    public void AddDigit(string digit)
    {
        if (inputCode.Length < maxCodeLength)
        {
            inputCode += digit; // Add the digit to the input code
            UpdateCodeDisplay(); // Update the displayed code
        }
    }

    // Method to remove the last digit
    public void RemoveDigit()
    {
        if (inputCode.Length > 0)
        {
            inputCode = inputCode.Substring(0, inputCode.Length - 1); // Remove last digit
            UpdateCodeDisplay(); // Update the displayed code
        }
    }

    // Method to check if the entered code is correct
    public void CheckCode()
    {
        if (inputCode == correctCode)
        {
            Debug.Log("Correct Code Entered!"); // Perform actions for correct code
            ResetKeypad(); // Reset keypad after success
            keypadUI.SetActive(false);
            disable.SetActive(false);
            //disable.GetComponent<BoxCollider>().enabled = false;
            door.transform.position += new Vector3(0, 4, 0);

        }
        else
        {
            Debug.Log("Incorrect Code!"); // Feedback for incorrect code
            ResetKeypad(); // Reset keypad after failure
        }
    }


    // Method to reset the keypad
    private void ResetKeypad()
    {
        inputCode = ""; // Clear the entered code
        UpdateCodeDisplay(); // Update the displayed code
        keypadUI.SetActive(false); // Hide the keypad UI
        FPSController.enabled = true;  // Enable FPS controller again
        Cursor.visible = false;  // Hide the cursor
        Cursor.lockState = CursorLockMode.Locked;  // Lock the cursor again
        playerRigid.constraints = RigidbodyConstraints.FreezePositionZ | RigidbodyConstraints.FreezePositionX |
                                  RigidbodyConstraints.FreezeRotationY | RigidbodyConstraints.FreezeRotationZ |
                                  RigidbodyConstraints.FreezeRotationX;
    }

    // Update the UI text to show the entered code
    private void UpdateCodeDisplay()
    {
        codeDisplay.text = inputCode; // Set the displayed text to the entered code
    }
}