using UnityEngine;
using UnityEngine.SceneManagement;

public class PauseMenu : MonoBehaviour
{
    public GameObject pauseMenuUI;
    private bool isPaused = false;

    public Rigidbody playerRigid;
    public SimpleFPS FPSController;


    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (isPaused)
            {
                Resume();
            }
            else
            {
                
                Pause();
                
            }
        }
    }

    public void Resume()
    {
        pauseMenuUI.SetActive(false);
        //Time.timeScale = 1f; // Resume game time
        isPaused = false;

        // Re-enable player controls
        playerRigid.isKinematic = false;
        FPSController.enabled = true;
        Cursor.visible = false;
        Cursor.lockState = CursorLockMode.Locked; // Unlock cursor
    }

    void Pause()
    {
        pauseMenuUI.SetActive(true);
       // Time.timeScale = 0f; // Pause game time
        isPaused = true;

        // Disable player controls
        playerRigid.isKinematic = true;
        FPSController.enabled = false;
        Cursor.visible = true;  // Show the mouse cursor
        Cursor.lockState = CursorLockMode.None;  // Unlock cursor
    }

    public void QuitGame()
    {
        Time.timeScale = 1f; // Ensure time is normal on exit
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex - 1);
    }
}